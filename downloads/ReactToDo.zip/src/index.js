import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class App extends React.Component {

  constructor() {
    super()
  }
  
  render() {
    return (
      <div className="app">
        <p>Add ToDo Item:</p>
        <input className="newItem"/><button>Add Item</button>
        <p>Todo list:</p>
        <ol className="list">
        </ol>
      </div>
    );
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
